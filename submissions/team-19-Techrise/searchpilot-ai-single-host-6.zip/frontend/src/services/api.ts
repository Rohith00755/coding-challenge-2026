import { DashboardSummaryResponse, SearchTermItem, NegativeKeywordItem, AuditLogItem } from '../types';

const API_BASE = '/api';

// Server errors are usually JSON ({detail}) but can be plain text/HTML (e.g. a 500).
async function readError(res: Response, fallback: string): Promise<string> {
  try {
    const text = await res.text();
    try {
      const data = JSON.parse(text);
      if (typeof data.detail === 'string') return data.detail;
      if (Array.isArray(data.detail)) return data.detail.map((d: any) => d.msg).join('; ');
    } catch {
      /* not JSON */
    }
    return text ? `${fallback}: ${text.slice(0, 200)}` : fallback;
  } catch {
    return fallback;
  }
}

export const api = {
  async getHealth() {
    const res = await fetch(`${API_BASE}/health`);
    return res.json();
  },

  async loadDemo() {
    const res = await fetch(`${API_BASE}/load-demo`, {
      method: 'POST'
    });
    return res.json();
  },

  async runStressTest() {
    const res = await fetch(`${API_BASE}/stress-test`, {
      method: 'POST'
    });
    return res.json();
  },

  async getSummary(datasetId?: string): Promise<DashboardSummaryResponse> {
    const url = datasetId ? `${API_BASE}/summary?dataset_id=${encodeURIComponent(datasetId)}` : `${API_BASE}/summary`;
    const res = await fetch(url);
    return res.json();
  },

  async getResults(params: {
    datasetId?: string;
    search?: string;
    action?: string;
    campaign?: string;
    needsReview?: boolean;
    confidenceBand?: string;
    sortBy?: string;
    sortDir?: string;
    page?: number;
    pageSize?: number;
  }) {
    const query = new URLSearchParams();
    if (params.datasetId) query.set('dataset_id', params.datasetId);
    if (params.search) query.set('search', params.search);
    if (params.action && params.action !== 'ALL') query.set('action', params.action);
    if (params.campaign && params.campaign !== 'ALL') query.set('campaign', params.campaign);
    if (params.needsReview !== undefined) query.set('needs_review', String(params.needsReview));
    if (params.confidenceBand && params.confidenceBand !== 'ALL') query.set('confidence_band', params.confidenceBand);
    if (params.sortBy) query.set('sort_by', params.sortBy);
    if (params.sortDir) query.set('sort_dir', params.sortDir);
    if (params.page) query.set('page', String(params.page));
    if (params.pageSize) query.set('page_size', String(params.pageSize));

    const res = await fetch(`${API_BASE}/results?${query.toString()}`);
    return res.json();
  },

  async getSingleTerm(termId: number): Promise<SearchTermItem> {
    const res = await fetch(`${API_BASE}/results/${termId}`);
    return res.json();
  },

  async reviewTerm(termId: number, action: string, notes?: string) {
    const res = await fetch(`${API_BASE}/review`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ term_id: termId, action, reviewer_notes: notes })
    });
    return res.json();
  },

  async batchReview(termIds: number[], action: string, notes?: string) {
    const res = await fetch(`${API_BASE}/batch-review`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ term_ids: termIds, action, reviewer_notes: notes })
    });
    return res.json();
  },

  async getNegativeKeywords(datasetId?: string): Promise<{ items: NegativeKeywordItem[]; total_count: number; total_estimated_waste: number }> {
    const url = datasetId ? `${API_BASE}/negative-keywords?dataset_id=${encodeURIComponent(datasetId)}` : `${API_BASE}/negative-keywords`;
    const res = await fetch(url);
    return res.json();
  },

  async getAuditLogs(): Promise<{ logs: AuditLogItem[] }> {
    const res = await fetch(`${API_BASE}/audit-logs`);
    return res.json();
  },

  async uploadCsv(file: File) {
    const formData = new FormData();
    formData.append('file', file);
    const res = await fetch(`${API_BASE}/upload`, {
      method: 'POST',
      body: formData
    });
    if (!res.ok) {
      throw new Error(await readError(res, 'Upload failed'));
    }
    return res.json();
  },

  // The server keeps the cleaned upload, so only the dataset id is needed here.
  async analyzeDataset(datasetId: string, targetCpa: number = 35.0, targetRoas: number = 3.0) {
    const formData = new FormData();
    formData.append('dataset_id', datasetId);
    formData.append('target_cpa', String(targetCpa));
    formData.append('target_roas', String(targetRoas));

    const res = await fetch(`${API_BASE}/analyze`, {
      method: 'POST',
      body: formData
    });
    if (!res.ok) {
      throw new Error(await readError(res, 'Analysis failed'));
    }
    return res.json();
  },

  getExportCsvUrl(datasetId?: string) {
    return datasetId ? `${API_BASE}/export/csv?dataset_id=${encodeURIComponent(datasetId)}` : `${API_BASE}/export/csv`;
  },

  getExportNegativesUrl(datasetId?: string) {
    return datasetId ? `${API_BASE}/export/google-ads-negatives?dataset_id=${encodeURIComponent(datasetId)}` : `${API_BASE}/export/google-ads-negatives`;
  }
};

