import React from 'react';
import { 
  FileText, 
  Download, 
  ShieldAlert, 
  Printer, 
  Sparkles
} from 'lucide-react';
import { DashboardSummaryResponse } from '../types';
import { api } from '../services/api';

interface ReportsViewProps {
  data: DashboardSummaryResponse;
}

export const ReportsView: React.FC<ReportsViewProps> = ({ data }) => {
  const kpis = data?.kpis;
  const campaigns = data?.campaign_breakdown || [];

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8 pb-16">
      
      {/* Header and Print/Export Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-200 gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Executive Triage Audit & Reports</h2>
          <p className="text-xs text-slate-500 mt-1">
            Downloadable audit reports, financial waste elimination summary, and methodology documentation.
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={handlePrint}
            className="flex items-center space-x-1.5 px-3 py-2 rounded-xl bg-white hover:bg-slate-50 text-slate-700 text-xs font-medium border border-slate-200 shadow-sm transition-all"
          >
            <Printer className="w-4 h-4 text-slate-500" />
            <span>Print Report</span>
          </button>

          <a
            href={api.getExportCsvUrl(data?.dataset_id)}
            download
            className="flex items-center space-x-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs font-semibold shadow-md shadow-blue-500/20 transition-all"
          >
            <Download className="w-4 h-4" />
            <span>Download Enriched CSV</span>
          </a>
        </div>
      </div>

      {/* Executive Summary Card */}
      <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-6">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900">SearchPilot Decision Synthesis</h3>
            <p className="text-xs text-slate-500">Campaign optimization & waste prevention assessment</p>
          </div>
        </div>

        {kpis ? (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1">
              <span className="text-[11px] text-slate-500 font-medium">Total Analyzed</span>
              <p className="text-xl font-bold text-slate-900 font-mono">{kpis.total_terms.toLocaleString()}</p>
              <span className="text-[10px] text-slate-500">{kpis.total_clicks} Clicks</span>
            </div>

            <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 space-y-1">
              <span className="text-[11px] text-emerald-800 font-medium">Promote Candidates</span>
              <p className="text-xl font-bold text-emerald-700 font-mono">{kpis.promote_count}</p>
              <span className="text-[10px] text-emerald-800">High commercial intent</span>
            </div>

            <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 space-y-1">
              <span className="text-[11px] text-rose-800 font-medium">Waste Prevented</span>
              <p className="text-xl font-bold text-rose-700 font-mono">${kpis.estimated_waste_saved.toFixed(2)}</p>
              <span className="text-[10px] text-rose-800">{kpis.block_count} Negative queries</span>
            </div>

            <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 space-y-1">
              <span className="text-[11px] text-amber-800 font-medium">Uncertainty Held</span>
              <p className="text-xl font-bold text-amber-700 font-mono">{kpis.ignore_count}</p>
              <span className="text-[10px] text-amber-800">Low sample size / monitor</span>
            </div>
          </div>
        ) : (
          <p className="text-xs text-slate-500">No active metrics available.</p>
        )}
      </div>

      {/* Methodology & Statistical Integrity Note */}
      <div className="p-6 rounded-2xl bg-blue-50/40 border border-blue-200 shadow-sm space-y-4">
        <h4 className="text-sm font-bold text-slate-900 flex items-center space-x-2">
          <ShieldAlert className="w-4 h-4 text-blue-600" />
          <span>Scientific Governance & Methodology Statement</span>
        </h4>
        <div className="text-xs text-slate-700 leading-relaxed space-y-2 font-sans bg-white p-4 rounded-xl border border-blue-100 shadow-sm">
          <p>
            • <b>Single-Conversion Trap Mitigation:</b> Standard rules naively promote queries with 1 click and 1 conversion (100% CVR). SearchPilot AI calculates the Wilson 95% confidence lower bound, recognizing that N=1 carries high statistical variance. Such queries are held in observation or routed to Human Review.
          </p>
          <p>
            • <b>Collision-Protected Negative Keywords:</b> When recommending negative keywords, SearchPilot tokenizes the query and compares proposed negative phrases against all converting queries in the account, preventing accidental exclusion of valuable traffic.
          </p>
          <p>
            • <b>Transparent Reasoning:</b> Recommendations are derived from explainable multi-factor heuristics (sample size, intent lexicons, target CPA benchmarks) rather than black-box claims.
          </p>
        </div>
      </div>

      {/* Campaign Summary Table */}
      {campaigns.length > 0 && (
        <div className="rounded-2xl bg-white border border-slate-200 overflow-hidden shadow-sm">
          <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
            <h4 className="text-sm font-bold text-slate-900">Campaign Distribution Summary</h4>
            <span className="text-xs text-slate-500 font-mono font-medium">{campaigns.length} Campaigns</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead className="bg-slate-50 text-slate-600 font-mono text-[11px]">
                <tr>
                  <th className="py-3 px-4 font-semibold">Campaign Name</th>
                  <th className="py-3 px-3 text-right font-semibold">Total Queries</th>
                  <th className="py-3 px-3 text-right text-emerald-700 font-semibold">Promote</th>
                  <th className="py-3 px-3 text-right text-rose-700 font-semibold">Block</th>
                  <th className="py-3 px-3 text-right text-amber-700 font-semibold">Ignore</th>
                  <th className="py-3 px-3 text-right font-semibold">Spend ($)</th>
                  <th className="py-3 px-3 text-right text-blue-700 font-semibold">Value ($)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono text-[11px]">
                {campaigns.map((c, i) => (
                  <tr key={i} className="hover:bg-slate-50">
                    <td className="py-2.5 px-4 font-sans font-semibold text-slate-900">{c.campaign}</td>
                    <td className="py-2.5 px-3 text-right text-slate-600">{c.total}</td>
                    <td className="py-2.5 px-3 text-right text-emerald-700 font-bold">{c.promote}</td>
                    <td className="py-2.5 px-3 text-right text-rose-700 font-bold">{c.block}</td>
                    <td className="py-2.5 px-3 text-right text-amber-700 font-bold">{c.ignore}</td>
                    <td className="py-2.5 px-3 text-right text-slate-700">${c.spend.toFixed(2)}</td>
                    <td className="py-2.5 px-3 text-right text-blue-700 font-bold">${c.conversion_value.toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

    </div>
  );
};
