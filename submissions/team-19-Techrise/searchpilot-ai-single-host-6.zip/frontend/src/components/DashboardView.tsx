import React from 'react';
import { 
  BarChart, 
  Bar, 
  PieChart, 
  Pie, 
  Cell, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  Legend
} from 'recharts';
import { 
  TrendingUp, 
  ShieldAlert, 
  CheckCircle2, 
  HelpCircle, 
  DollarSign, 
  Eye, 
  ArrowUpRight,
  Sparkles,
  AlertOctagon
} from 'lucide-react';
import { DashboardSummaryResponse } from '../types';

interface DashboardViewProps {
  data: DashboardSummaryResponse;
  onNavigateTab: (tab: string, filter?: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ data, onNavigateTab }) => {
  if (!data || !data.has_data || !data.kpis) {
    return (
      <div className="p-12 text-center rounded-2xl bg-white border border-slate-200 shadow-sm space-y-4">
        <Sparkles className="w-10 h-10 text-blue-600 mx-auto animate-bounce" />
        <h3 className="text-xl font-bold text-slate-900">No Dataset Loaded Yet</h3>
        <p className="text-slate-500 text-sm max-w-md mx-auto">
          Upload a Google Ads search term CSV report or load the sample dataset to view live analytics.
        </p>
        <button
          onClick={() => onNavigateTab('upload')}
          className="px-5 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs shadow-md shadow-blue-500/20 transition-all"
        >
          Go to Upload Center
        </button>
      </div>
    );
  }

  const { kpis, confidence_distribution, campaign_breakdown, action_economics } = data;
  const total = kpis.total_terms || 1;

  // Donut chart data for Triage breakdown
  const donutData = [
    { name: 'Promote', value: kpis.promote_count, color: '#059669' },
    { name: 'Block', value: kpis.block_count, color: '#E11D48' },
    { name: 'Ignore', value: kpis.ignore_count, color: '#D97706' },
  ];

  // Confidence distribution histogram data
  const confData = confidence_distribution ? [
    { name: 'High (80-100%)', count: confidence_distribution.high_conf, color: '#059669' },
    { name: 'Medium (60-79%)', count: confidence_distribution.med_conf, color: '#0284C7' },
    { name: 'Low (<60%)', count: confidence_distribution.low_conf, color: '#D97706' },
  ] : [];

  const tooltipStyle = { 
    backgroundColor: '#FFFFFF', 
    borderColor: '#E2E8F0', 
    borderRadius: '10px', 
    boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
    color: '#0F172A' 
  };

  return (
    <div className="space-y-8 pb-16">
      
      {/* Header Info */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 tracking-tight">Executive Triage Analytics</h2>
          <p className="text-slate-500 text-xs mt-0.5">
            Computed directly from dataset <span className="font-mono text-blue-600 font-semibold">{data.dataset_id}</span>
          </p>
        </div>
        <div className="flex items-center space-x-3">
          <button
            onClick={() => onNavigateTab('review')}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-amber-50 border border-amber-200 text-amber-800 text-xs font-semibold hover:bg-amber-100 transition-all shadow-sm"
          >
            <AlertOctagon className="w-3.5 h-3.5 text-amber-600" />
            <span>Review Queue ({kpis.review_needed_count})</span>
          </button>
          <button
            onClick={() => onNavigateTab('negatives')}
            className="flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-rose-50 border border-rose-200 text-rose-800 text-xs font-semibold hover:bg-rose-100 transition-all shadow-sm"
          >
            <ShieldAlert className="w-3.5 h-3.5 text-rose-600" />
            <span>Block Candidates ({kpis.block_count})</span>
          </button>
        </div>
      </div>

      {/* KPI Metric Cards Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        
        {/* Total Analyzed */}
        <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-slate-500 text-xs">
            <span>Total Queries</span>
            <Eye className="w-3.5 h-3.5 text-blue-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900 font-mono">
            {kpis.total_terms.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-500">
            {kpis.total_clicks.toLocaleString()} clicks tracked
          </div>
        </div>

        {/* Promote */}
        <div 
          onClick={() => onNavigateTab('explorer', 'PROMOTE')}
          className="p-4 rounded-xl bg-emerald-50/70 border border-emerald-200 shadow-sm space-y-2 cursor-pointer hover:border-emerald-400 hover:shadow transition-all"
        >
          <div className="flex items-center justify-between text-emerald-800 text-xs font-semibold">
            <span>Promote</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded bg-emerald-100 font-mono text-emerald-800">
              {((kpis.promote_count / total) * 100).toFixed(1)}%
            </span>
          </div>
          <div className="text-2xl font-bold text-emerald-700 font-mono">
            {kpis.promote_count}
          </div>
          <div className="text-[11px] text-emerald-700 flex items-center">
            <span>High-value scale</span>
            <ArrowUpRight className="w-3 h-3 ml-0.5" />
          </div>
        </div>

        {/* Block */}
        <div 
          onClick={() => onNavigateTab('explorer', 'BLOCK')}
          className="p-4 rounded-xl bg-rose-50/70 border border-rose-200 shadow-sm space-y-2 cursor-pointer hover:border-rose-400 hover:shadow transition-all"
        >
          <div className="flex items-center justify-between text-rose-800 text-xs font-semibold">
            <span>Block</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded bg-rose-100 font-mono text-rose-800">
              {((kpis.block_count / total) * 100).toFixed(1)}%
            </span>
          </div>
          <div className="text-2xl font-bold text-rose-700 font-mono">
            {kpis.block_count}
          </div>
          <div className="text-[11px] text-rose-700">
            Negative exclusions
          </div>
        </div>

        {/* Ignore */}
        <div 
          onClick={() => onNavigateTab('explorer', 'IGNORE')}
          className="p-4 rounded-xl bg-amber-50/70 border border-amber-200 shadow-sm space-y-2 cursor-pointer hover:border-amber-400 hover:shadow transition-all"
        >
          <div className="flex items-center justify-between text-amber-800 text-xs font-semibold">
            <span>Ignore / Observe</span>
            <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-100 font-mono text-amber-800">
              {((kpis.ignore_count / total) * 100).toFixed(1)}%
            </span>
          </div>
          <div className="text-2xl font-bold text-amber-700 font-mono">
            {kpis.ignore_count}
          </div>
          <div className="text-[11px] text-amber-700">
            Insufficient volume
          </div>
        </div>

        {/* Waste Saved */}
        <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-slate-500 text-xs">
            <span>Spend in Block Terms</span>
            <DollarSign className="w-3.5 h-3.5 text-rose-600" />
          </div>
          <div className="text-2xl font-bold text-rose-600 font-mono">
            ${kpis.estimated_waste_saved.toLocaleString(undefined, { minimumFractionDigits: 2 })}
          </div>
          <div className="text-[11px] text-slate-500">
            Recoverable ad spend
          </div>
        </div>

        {/* Human Review Needed */}
        <div 
          onClick={() => onNavigateTab('review')}
          className="p-4 rounded-xl bg-indigo-50/70 border border-indigo-200 shadow-sm space-y-2 cursor-pointer hover:border-indigo-400 hover:shadow transition-all"
        >
          <div className="flex items-center justify-between text-indigo-800 text-xs font-semibold">
            <span>Needs Review</span>
            <CheckCircle2 className="w-3.5 h-3.5 text-indigo-600" />
          </div>
          <div className="text-2xl font-bold text-indigo-700 font-mono">
            {kpis.review_needed_count}
          </div>
          <div className="text-[11px] text-indigo-700">
            Ambiguous edge cases
          </div>
        </div>

      </div>

      {/* Main Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* 1. Triage Distribution Donut */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-bold text-slate-900">Recommendation Breakdown</h4>
            <span className="text-[11px] font-mono text-slate-500">{kpis.total_terms} total</span>
          </div>

          <div className="h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={donutData}
                  cx="50%"
                  cy="50%"
                  innerRadius={55}
                  outerRadius={85}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {donutData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip contentStyle={tooltipStyle} />
                <Legend 
                  verticalAlign="bottom" 
                  height={36} 
                  formatter={(value) => <span className="text-xs text-slate-700 font-medium">{value}</span>}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* 2. Confidence Score Distribution */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-bold text-slate-900">Confidence Calibrations</h4>
            <span className="text-[11px] font-mono text-blue-600 font-bold">Avg: {kpis.avg_confidence}%</span>
          </div>

          <div className="h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={confData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <XAxis dataKey="name" tick={{ fill: '#64748B', fontSize: 10 }} />
                <YAxis tick={{ fill: '#64748B', fontSize: 10 }} />
                <Tooltip contentStyle={tooltipStyle} />
                <Bar dataKey="count" radius={[6, 6, 0, 0]}>
                  {confData.map((entry, index) => (
                    <Cell key={`conf-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* 3. Financial Performance (Spend vs Value by Action) */}
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-bold text-slate-900">Economic Distribution ($)</h4>
            <span className="text-[11px] font-mono text-emerald-700 font-bold">ROAS: {kpis.overall_roas}x</span>
          </div>

          <div className="h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart 
                data={action_economics || []} 
                margin={{ top: 10, right: 10, left: -10, bottom: 0 }}
              >
                <XAxis dataKey="action" tick={{ fill: '#64748B', fontSize: 10 }} />
                <YAxis tick={{ fill: '#64748B', fontSize: 10 }} />
                <Tooltip contentStyle={tooltipStyle} />
                <Legend 
                  verticalAlign="bottom" 
                  height={36} 
                  formatter={(value) => <span className="text-xs text-slate-700 font-medium">{value}</span>}
                />
                <Bar dataKey="spend" name="Spend ($)" fill="#94A3B8" radius={[4, 4, 0, 0]} />
                <Bar dataKey="conv_value" name="Value ($)" fill="#059669" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

      </div>

      {/* Campaign Triage Breakdown Stack */}
      {campaign_breakdown && campaign_breakdown.length > 0 && (
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="text-sm font-bold text-slate-900">Campaign-Level Triage Profile</h4>
              <p className="text-xs text-slate-500">Comparing Promote, Block, and Ignore counts across ad campaigns</p>
            </div>
            <span className="text-xs text-slate-600 font-mono font-medium">
              {campaign_breakdown.length} Active Campaigns
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={campaign_breakdown} layout="vertical" margin={{ top: 10, right: 20, left: 100, bottom: 0 }}>
                <XAxis type="number" tick={{ fill: '#64748B', fontSize: 10 }} />
                <YAxis 
                  dataKey="campaign" 
                  type="category" 
                  tick={{ fill: '#334155', fontSize: 11 }} 
                  width={140}
                />
                <Tooltip contentStyle={tooltipStyle} />
                <Legend 
                  verticalAlign="top" 
                  height={36} 
                  formatter={(value) => <span className="text-xs text-slate-700 font-medium">{value}</span>}
                />
                <Bar dataKey="promote" name="Promote" stackId="a" fill="#059669" />
                <Bar dataKey="block" name="Block" stackId="a" fill="#E11D48" />
                <Bar dataKey="ignore" name="Ignore" stackId="a" fill="#D97706" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

    </div>
  );
};
