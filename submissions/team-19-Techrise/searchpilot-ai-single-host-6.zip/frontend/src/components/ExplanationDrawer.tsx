import React, { useState } from 'react';
import { 
  X, 
  CheckCircle2, 
  ShieldAlert, 
  AlertCircle, 
  Info, 
  HelpCircle, 
  DollarSign, 
  FileEdit, 
  Sparkles, 
  Save 
} from 'lucide-react';
import { SearchTermItem, TriageAction } from '../types';

interface ExplanationDrawerProps {
  term: SearchTermItem | null;
  onClose: () => void;
  onReviewSubmit: (termId: number, action: TriageAction, notes: string) => void;
}

export const ExplanationDrawer: React.FC<ExplanationDrawerProps> = ({
  term,
  onClose,
  onReviewSubmit
}) => {
  if (!term) return null;

  const [selectedAction, setSelectedAction] = useState<TriageAction>(term.action);
  const [notes, setNotes] = useState<string>(term.reviewer_notes || '');
  const [isSaving, setIsSaving] = useState<boolean>(false);

  const handleSave = async () => {
    setIsSaving(true);
    await onReviewSubmit(term.id, selectedAction, notes);
    setIsSaving(false);
  };

  const getActionBadge = (act: TriageAction) => {
    switch (act) {
      case 'PROMOTE':
        return (
          <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-800 border border-emerald-200 flex items-center space-x-1.5">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            <span>PROMOTE</span>
          </span>
        );
      case 'BLOCK':
        return (
          <span className="px-3 py-1 rounded-full text-xs font-bold bg-rose-50 text-rose-800 border border-rose-200 flex items-center space-x-1.5">
            <ShieldAlert className="w-3.5 h-3.5 text-rose-600" />
            <span>BLOCK</span>
          </span>
        );
      case 'IGNORE':
        return (
          <span className="px-3 py-1 rounded-full text-xs font-bold bg-amber-50 text-amber-800 border border-amber-200 flex items-center space-x-1.5">
            <AlertCircle className="w-3.5 h-3.5 text-amber-600" />
            <span>IGNORE</span>
          </span>
        );
    }
  };

  const getConfidenceColor = (conf: number) => {
    if (conf >= 80) return 'text-emerald-800 bg-emerald-50 border-emerald-200';
    if (conf >= 60) return 'text-blue-800 bg-blue-50 border-blue-200';
    return 'text-amber-800 bg-amber-50 border-amber-200';
  };

  return (
    <div className="fixed inset-y-0 right-0 z-50 w-full sm:w-[540px] bg-white border-l border-slate-200 shadow-2xl flex flex-col">
      
      {/* Header */}
      <div className="p-6 border-b border-slate-100 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900">Explainable Recommendation</h3>
            <p className="text-xs text-slate-500">Term ID #{term.id}</p>
          </div>
        </div>
        <button
          onClick={onClose}
          className="p-2 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-all"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Drawer Body */}
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        
        {/* Term & Recommendation Banner */}
        <div className="p-4 rounded-xl bg-blue-50/50 border border-blue-100 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs uppercase font-mono tracking-wider text-slate-500 font-semibold">Search Query</span>
            <div className="flex items-center space-x-2">
              {getActionBadge(term.action)}
            </div>
          </div>
          <h2 className="text-lg font-bold text-slate-900 break-words">
            "{term.query}"
          </h2>
          <div className="flex flex-wrap items-center gap-2 text-xs text-slate-600">
            <span className="px-2 py-0.5 rounded bg-white border border-slate-200">Campaign: {term.campaign}</span>
            <span className="px-2 py-0.5 rounded bg-white border border-slate-200">Ad Group: {term.ad_group}</span>
            <span className="px-2 py-0.5 rounded bg-white border border-slate-200">Match: {term.match_type}</span>
          </div>
        </div>

        {/* Confidence & Evidence Meter */}
        <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-slate-700 flex items-center space-x-1.5">
              <Info className="w-4 h-4 text-blue-600" />
              <span>Confidence Score</span>
            </span>
            <span className={`px-2.5 py-0.5 rounded-full border text-xs font-mono font-bold ${getConfidenceColor(term.confidence)}`}>
              {term.confidence}%
            </span>
          </div>

          <div className="w-full h-2 rounded-full bg-slate-200 overflow-hidden">
            <div 
              className={`h-full rounded-full transition-all duration-500 ${
                term.confidence >= 80 ? 'bg-emerald-500' : term.confidence >= 60 ? 'bg-blue-500' : 'bg-amber-500'
              }`}
              style={{ width: `${term.confidence}%` }}
            ></div>
          </div>

          <p className="text-[11px] text-slate-500">
            {term.confidence >= 80 
              ? 'High Confidence: Ample sample size and consistent economic/intent signals.'
              : term.confidence >= 60
              ? 'Medium Confidence: Noticeable pattern with moderate sample variance.'
              : 'Low Confidence: High statistical uncertainty. Human review recommended.'}
          </p>
        </div>

        {/* Key Performance Metrics Grid */}
        <div className="grid grid-cols-3 gap-3">
          <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 text-center">
            <span className="text-[11px] text-slate-500">Impressions</span>
            <p className="text-sm font-bold text-slate-900 font-mono mt-0.5">{term.impressions}</p>
          </div>
          <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 text-center">
            <span className="text-[11px] text-slate-500">Clicks</span>
            <p className="text-sm font-bold text-slate-900 font-mono mt-0.5">{term.clicks}</p>
          </div>
          <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 text-center">
            <span className="text-[11px] text-slate-500">Spend</span>
            <p className="text-sm font-bold text-slate-900 font-mono mt-0.5">${term.cost.toFixed(2)}</p>
          </div>
          <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 text-center">
            <span className="text-[11px] text-slate-500">Conversions</span>
            <p className="text-sm font-bold text-emerald-700 font-mono mt-0.5">{term.conversions}</p>
          </div>
          <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 text-center">
            <span className="text-[11px] text-slate-500">Conv. Rate</span>
            <p className="text-sm font-bold text-slate-900 font-mono mt-0.5">{term.cvr}%</p>
          </div>
          <div className="p-3 rounded-lg bg-slate-50 border border-slate-200 text-center">
            <span className="text-[11px] text-slate-500">ROAS</span>
            <p className="text-sm font-bold text-blue-700 font-mono mt-0.5">{term.roas}x</p>
          </div>
        </div>

        {/* Why this recommendation was made */}
        <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-sm space-y-2">
          <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center space-x-1.5">
            <CheckCircle2 className="w-4 h-4 text-blue-600" />
            <span>Why This Recommendation Was Made</span>
          </h4>
          <p className="text-xs text-slate-700 leading-relaxed bg-slate-50 p-3 rounded-lg border border-slate-100 font-sans">
            {term.reason}
          </p>
        </div>

        {/* What Information Is Missing */}
        <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-sm space-y-2">
          <h4 className="text-xs font-bold text-amber-800 uppercase tracking-wider flex items-center space-x-1.5">
            <HelpCircle className="w-4 h-4 text-amber-600" />
            <span>Information Gap & Statistical Limits</span>
          </h4>
          <p className="text-xs text-amber-900 leading-relaxed bg-amber-50/60 p-3 rounded-lg border border-amber-200">
            {term.missing_info || 'Sufficient baseline information available for this decision.'}
          </p>
        </div>

        {/* Financial Implications */}
        <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-sm space-y-2">
          <h4 className="text-xs font-bold text-emerald-800 uppercase tracking-wider flex items-center space-x-1.5">
            <DollarSign className="w-4 h-4 text-emerald-600" />
            <span>Potential Financial Impact</span>
          </h4>
          <p className="text-xs text-emerald-900 leading-relaxed bg-emerald-50/60 p-3 rounded-lg border border-emerald-200">
            {term.financial_impact || 'Neutral budgetary impact.'}
          </p>
        </div>

        {/* Human Review & Action Override Studio */}
        <div className="p-4 rounded-xl bg-blue-50/30 border border-blue-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center space-x-1.5">
              <FileEdit className="w-4 h-4 text-blue-600" />
              <span>Analyst Override & Governance</span>
            </h4>
            <span className="text-[10px] text-blue-700 font-mono font-bold">
              Status: {term.review_status}
            </span>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs text-slate-700 font-medium">Change Recommendation To:</label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setSelectedAction('PROMOTE')}
                className={`py-2 px-3 rounded-lg text-xs font-bold transition-all ${
                  selectedAction === 'PROMOTE'
                    ? 'bg-emerald-600 text-white shadow-md'
                    : 'bg-white border border-slate-200 text-slate-600 hover:text-slate-900'
                }`}
              >
                PROMOTE
              </button>
              <button
                type="button"
                onClick={() => setSelectedAction('BLOCK')}
                className={`py-2 px-3 rounded-lg text-xs font-bold transition-all ${
                  selectedAction === 'BLOCK'
                    ? 'bg-rose-600 text-white shadow-md'
                    : 'bg-white border border-slate-200 text-slate-600 hover:text-slate-900'
                }`}
              >
                BLOCK
              </button>
              <button
                type="button"
                onClick={() => setSelectedAction('IGNORE')}
                className={`py-2 px-3 rounded-lg text-xs font-bold transition-all ${
                  selectedAction === 'IGNORE'
                    ? 'bg-amber-600 text-white shadow-md'
                    : 'bg-white border border-slate-200 text-slate-600 hover:text-slate-900'
                }`}
              >
                IGNORE
              </button>
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs text-slate-700 font-medium">Analyst Review Notes (Logged to Audit Trail):</label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Explain rationale for approving or overriding this recommendation..."
              rows={3}
              className="w-full text-xs bg-white border border-slate-200 rounded-lg p-2.5 text-slate-800 placeholder-slate-400 focus:outline-none focus:border-blue-500 shadow-sm"
            />
          </div>

          <button
            onClick={handleSave}
            disabled={isSaving}
            className="w-full py-2.5 rounded-lg font-semibold text-xs bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white flex items-center justify-center space-x-2 shadow-md shadow-blue-500/20 active:scale-98 transition-all disabled:opacity-50"
          >
            <Save className="w-3.5 h-3.5" />
            <span>{isSaving ? 'Logging Decision...' : 'Approve & Save Triage Decision'}</span>
          </button>
        </div>

      </div>

    </div>
  );
};
