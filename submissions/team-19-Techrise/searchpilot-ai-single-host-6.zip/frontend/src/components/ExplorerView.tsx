import React, { useState, useEffect } from 'react';
import { 
  Search, 
  ArrowUpDown, 
  ChevronDown, 
  ChevronUp, 
  Download, 
  ChevronLeft, 
  ChevronRight, 
  CheckCircle2, 
  ShieldAlert, 
  AlertCircle,
  Eye,
  RefreshCw
} from 'lucide-react';
import { SearchTermItem, TriageAction } from '../types';
import { api } from '../services/api';

interface ExplorerViewProps {
  datasetId?: string;
  initialActionFilter?: string;
  onSelectTerm: (term: SearchTermItem) => void;
}

export const ExplorerView: React.FC<ExplorerViewProps> = ({
  datasetId,
  initialActionFilter = 'ALL',
  onSelectTerm
}) => {
  const [items, setItems] = useState<SearchTermItem[]>([]);
  const [totalCount, setTotalCount] = useState<number>(0);
  const [page, setPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(20);
  const [search, setSearch] = useState<string>('');
  const [actionFilter, setActionFilter] = useState<string>(initialActionFilter);
  const [needsReviewFilter, setNeedsReviewFilter] = useState<boolean | undefined>(undefined);
  const [confidenceBand, setConfidenceBand] = useState<string>('ALL');
  const [sortBy, setSortBy] = useState<string>('clicks');
  const [sortDir, setSortDir] = useState<string>('desc');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [selectedIds, setSelectedIds] = useState<number[]>([]);
  const [expandedRowId, setExpandedRowId] = useState<number | null>(null);

  const fetchTerms = async () => {
    setIsLoading(true);
    try {
      const res = await api.getResults({
        datasetId,
        search,
        action: actionFilter,
        needsReview: needsReviewFilter,
        confidenceBand,
        sortBy,
        sortDir,
        page,
        pageSize
      });
      setItems(res.items || []);
      setTotalCount(res.total || 0);
    } catch (err) {
      console.error('Failed to fetch terms:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchTerms();
  }, [datasetId, page, pageSize, actionFilter, needsReviewFilter, confidenceBand, sortBy, sortDir]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setPage(1);
    fetchTerms();
  };

  const handleSort = (col: string) => {
    if (sortBy === col) {
      setSortDir(sortDir === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(col);
      setSortDir('desc');
    }
    setPage(1);
  };

  const handleSelectAll = () => {
    if (selectedIds.length === items.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(items.map((i) => i.id));
    }
  };

  const handleToggleSelect = (id: number) => {
    if (selectedIds.includes(id)) {
      setSelectedIds(selectedIds.filter((x) => x !== id));
    } else {
      setSelectedIds([...selectedIds, id]);
    }
  };

  const handleBatchAction = async (action: TriageAction) => {
    if (selectedIds.length === 0) return;
    try {
      await api.batchReview(selectedIds, action, `Bulk changed to ${action}`);
      setSelectedIds([]);
      fetchTerms();
    } catch (err) {
      console.error('Batch review failed:', err);
    }
  };

  const getActionBadge = (act: TriageAction) => {
    switch (act) {
      case 'PROMOTE':
        return (
          <span className="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-50 text-emerald-800 border border-emerald-200">
            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
            <span>PROMOTE</span>
          </span>
        );
      case 'BLOCK':
        return (
          <span className="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-rose-50 text-rose-800 border border-rose-200">
            <ShieldAlert className="w-3 h-3 text-rose-600" />
            <span>BLOCK</span>
          </span>
        );
      case 'IGNORE':
        return (
          <span className="inline-flex items-center space-x-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-50 text-amber-800 border border-amber-200">
            <AlertCircle className="w-3 h-3 text-amber-600" />
            <span>IGNORE</span>
          </span>
        );
    }
  };

  const totalPages = Math.ceil(totalCount / pageSize) || 1;

  return (
    <div className="space-y-6 pb-16">
      
      {/* Top Filter Bar */}
      <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-4">
        
        {/* Search & Action Filters */}
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          
          <form onSubmit={handleSearchSubmit} className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by query, campaign, ad group..."
              className="w-full pl-10 pr-4 py-2 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-blue-500 focus:bg-white transition-all"
            />
          </form>

          {/* Action Tabs */}
          <div className="flex flex-wrap items-center gap-2">
            {[
              { id: 'ALL', label: 'All Queries' },
              { id: 'PROMOTE', label: 'Promote' },
              { id: 'BLOCK', label: 'Block' },
              { id: 'IGNORE', label: 'Ignore' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => { setActionFilter(tab.id); setPage(1); }}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                  actionFilter === tab.id
                    ? 'bg-blue-50 text-blue-700 border border-blue-200 shadow-sm'
                    : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200 hover:bg-slate-50'
                }`}
              >
                {tab.label}
              </button>
            ))}

            <button
              onClick={() => { setNeedsReviewFilter(needsReviewFilter ? undefined : true); setPage(1); }}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                needsReviewFilter === true
                  ? 'bg-amber-100 text-amber-800 border border-amber-300 shadow-sm'
                  : 'bg-white text-slate-600 hover:text-slate-900 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              Needs Review
            </button>
          </div>

          {/* Export Button */}
          <div className="flex items-center space-x-2">
            <a
              href={api.getExportCsvUrl(datasetId)}
              download
              className="flex items-center space-x-1.5 px-3 py-2 rounded-xl bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 text-xs font-semibold shadow-sm transition-all"
            >
              <Download className="w-3.5 h-3.5 text-blue-600" />
              <span>Export CSV</span>
            </a>
          </div>

        </div>

        {/* Confidence Band & Secondary Filter Bar */}
        <div className="flex flex-wrap items-center justify-between text-xs text-slate-500 pt-3 border-t border-slate-100 gap-3">
          <div className="flex items-center space-x-4">
            <span className="font-semibold text-slate-700">Confidence Band:</span>
            <div className="flex items-center space-x-1.5">
              {['ALL', 'HIGH', 'MEDIUM', 'LOW'].map((b) => (
                <button
                  key={b}
                  onClick={() => { setConfidenceBand(b); setPage(1); }}
                  className={`px-2 py-0.5 rounded text-[11px] font-mono transition-all ${
                    confidenceBand === b ? 'bg-blue-100 text-blue-800 font-bold' : 'hover:text-slate-900'
                  }`}
                >
                  {b}
                </button>
              ))}
            </div>
          </div>

          {/* Batch action banner when rows are selected */}
          {selectedIds.length > 0 && (
            <div className="flex items-center space-x-2 bg-blue-50 px-3 py-1 rounded-lg border border-blue-200">
              <span className="text-blue-700 font-bold font-mono">{selectedIds.length} selected</span>
              <button
                onClick={() => handleBatchAction('PROMOTE')}
                className="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 hover:bg-emerald-200 text-[11px] font-bold"
              >
                Mark Promote
              </button>
              <button
                onClick={() => handleBatchAction('BLOCK')}
                className="px-2 py-0.5 rounded bg-rose-100 text-rose-800 hover:bg-rose-200 text-[11px] font-bold"
              >
                Mark Block
              </button>
              <button
                onClick={() => handleBatchAction('IGNORE')}
                className="px-2 py-0.5 rounded bg-amber-100 text-amber-800 hover:bg-amber-200 text-[11px] font-bold"
              >
                Mark Ignore
              </button>
            </div>
          )}

          <div>
            Showing <span className="font-mono text-slate-900 font-bold">{totalCount}</span> search terms
          </div>
        </div>

      </div>

      {/* Main Table */}
      <div className="rounded-2xl bg-white border border-slate-200 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-mono text-[11px]">
                <th className="py-3 px-3 w-10 text-center">
                  <input
                    type="checkbox"
                    checked={items.length > 0 && selectedIds.length === items.length}
                    onChange={handleSelectAll}
                    className="rounded bg-white border-slate-300 text-blue-600"
                  />
                </th>
                <th className="py-3 px-4 font-semibold cursor-pointer hover:text-slate-900" onClick={() => handleSort('query')}>
                  <div className="flex items-center space-x-1">
                    <span>Search Term</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="py-3 px-3 font-semibold cursor-pointer hover:text-slate-900" onClick={() => handleSort('campaign')}>
                  <div className="flex items-center space-x-1">
                    <span>Campaign</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="py-3 px-2 font-semibold text-right cursor-pointer hover:text-slate-900" onClick={() => handleSort('clicks')}>
                  <div className="flex items-center justify-end space-x-1">
                    <span>Clicks</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="py-3 px-2 font-semibold text-right cursor-pointer hover:text-slate-900" onClick={() => handleSort('cost')}>
                  <div className="flex items-center justify-end space-x-1">
                    <span>Cost</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="py-3 px-2 font-semibold text-right cursor-pointer hover:text-slate-900" onClick={() => handleSort('conversions')}>
                  <div className="flex items-center justify-end space-x-1">
                    <span>Conv</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="py-3 px-2 font-semibold text-right cursor-pointer hover:text-slate-900" onClick={() => handleSort('cvr')}>
                  <div className="flex items-center justify-end space-x-1">
                    <span>CVR</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="py-3 px-2 font-semibold text-right cursor-pointer hover:text-slate-900" onClick={() => handleSort('roas')}>
                  <div className="flex items-center justify-end space-x-1">
                    <span>ROAS</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="py-3 px-3 font-semibold text-center cursor-pointer hover:text-slate-900" onClick={() => handleSort('action')}>
                  <div className="flex items-center justify-center space-x-1">
                    <span>Action</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="py-3 px-2 font-semibold text-center cursor-pointer hover:text-slate-900" onClick={() => handleSort('confidence')}>
                  <div className="flex items-center justify-center space-x-1">
                    <span>Confidence</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="py-3 px-3 text-center">Details</th>
              </tr>
            </thead>

            <tbody className="divide-y divide-slate-100">
              {isLoading ? (
                <tr>
                  <td colSpan={11} className="py-12 text-center text-slate-500">
                    <RefreshCw className="w-6 h-6 mx-auto animate-spin text-blue-600 mb-2" />
                    <span>Loading search terms...</span>
                  </td>
                </tr>
              ) : items.length === 0 ? (
                <tr>
                  <td colSpan={11} className="py-12 text-center text-slate-500">
                    No search terms match your active filters.
                  </td>
                </tr>
              ) : (
                items.map((term) => {
                  const isSelected = selectedIds.includes(term.id);
                  const isExpanded = expandedRowId === term.id;
                  return (
                    <React.Fragment key={term.id}>
                      <tr className={`hover:bg-blue-50/50 transition-colors ${isSelected ? 'bg-blue-50/80' : ''}`}>
                        
                        {/* Checkbox */}
                        <td className="py-3 px-3 text-center">
                          <input
                            type="checkbox"
                            checked={isSelected}
                            onChange={() => handleToggleSelect(term.id)}
                            className="rounded bg-white border-slate-300 text-blue-600"
                          />
                        </td>

                        {/* Search Term Text */}
                        <td className="py-3 px-4 font-medium text-slate-900 max-w-[240px]">
                          <div className="truncate font-semibold text-slate-900" title={term.query}>
                            {term.query}
                          </div>
                          <div className="text-[10px] text-slate-500 truncate">
                            {term.match_type} match • {term.ad_group}
                          </div>
                        </td>

                        {/* Campaign */}
                        <td className="py-3 px-3 text-slate-600 max-w-[160px] truncate" title={term.campaign}>
                          {term.campaign}
                        </td>

                        {/* Clicks */}
                        <td className="py-3 px-2 text-right font-mono text-slate-700">
                          {term.clicks}
                        </td>

                        {/* Cost */}
                        <td className="py-3 px-2 text-right font-mono text-slate-700">
                          ${term.cost.toFixed(2)}
                        </td>

                        {/* Conversions */}
                        <td className="py-3 px-2 text-right font-mono font-bold text-emerald-700">
                          {term.conversions}
                        </td>

                        {/* CVR */}
                        <td className="py-3 px-2 text-right font-mono text-slate-700">
                          {term.cvr}%
                        </td>

                        {/* ROAS */}
                        <td className="py-3 px-2 text-right font-mono text-blue-700 font-bold">
                          {term.roas}x
                        </td>

                        {/* Action Badge */}
                        <td className="py-3 px-3 text-center whitespace-nowrap">
                          {getActionBadge(term.action)}
                        </td>

                        {/* Confidence */}
                        <td className="py-3 px-2 text-center font-mono">
                          <span className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                            term.confidence >= 80 ? 'text-emerald-800 bg-emerald-50 border border-emerald-200' :
                            term.confidence >= 60 ? 'text-blue-800 bg-blue-50 border border-blue-200' :
                            'text-amber-800 bg-amber-50 border border-amber-200'
                          }`}>
                            {term.confidence}%
                          </span>
                        </td>

                        {/* Side Drawer & Expansion */}
                        <td className="py-3 px-3 text-center">
                          <div className="flex items-center justify-center space-x-1">
                            <button
                              onClick={() => setExpandedRowId(isExpanded ? null : term.id)}
                              className="p-1 rounded text-slate-400 hover:text-slate-700"
                              title="Toggle quick explanation"
                            >
                              {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                            </button>
                            <button
                              onClick={() => onSelectTerm(term)}
                              className="p-1 rounded text-blue-600 hover:text-blue-700"
                              title="Open full explainable recommendation drawer"
                            >
                              <Eye className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>

                      </tr>

                      {/* Expandable Explanation Snippet */}
                      {isExpanded && (
                        <tr className="bg-slate-50 border-b border-slate-200">
                          <td colSpan={11} className="py-3 px-6 text-xs text-slate-700 space-y-2">
                            <div className="flex items-start space-x-2">
                              <span className="font-bold text-blue-700 uppercase font-mono text-[10px]">Triage Reason:</span>
                              <p className="text-slate-800">{term.reason}</p>
                            </div>
                            {term.missing_info && (
                              <div className="flex items-start space-x-2 text-[11px] text-amber-800">
                                <span className="font-bold uppercase font-mono text-[10px]">Missing Data:</span>
                                <p>{term.missing_info}</p>
                              </div>
                            )}
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-600 gap-3">
          <div className="flex items-center space-x-3">
            <span>Rows per page:</span>
            <select
              value={pageSize}
              onChange={(e) => { setPageSize(Number(e.target.value)); setPage(1); }}
              className="bg-white border border-slate-300 rounded px-2 py-1 text-slate-800 text-xs shadow-sm"
            >
              <option value={10}>10</option>
              <option value={20}>20</option>
              <option value={50}>50</option>
              <option value={100}>100</option>
            </select>
            <span>
              Page <span className="text-slate-900 font-mono font-bold">{page}</span> of <span className="text-slate-900 font-mono font-bold">{totalPages}</span>
            </span>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page <= 1}
              className="p-1.5 rounded-lg bg-white border border-slate-200 text-slate-600 hover:text-slate-900 shadow-sm disabled:opacity-40"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page >= totalPages}
              className="p-1.5 rounded-lg bg-white border border-slate-200 text-slate-600 hover:text-slate-900 shadow-sm disabled:opacity-40"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

      </div>

    </div>
  );
};
