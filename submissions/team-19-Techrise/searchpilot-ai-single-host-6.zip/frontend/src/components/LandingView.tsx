import React from 'react';
import { 
  Compass, 
  ArrowRight, 
  Sparkles, 
  ShieldCheck, 
  BrainCircuit, 
  SlidersHorizontal, 
  TrendingUp, 
  AlertTriangle, 
  FileCheck2, 
  CheckCircle2, 
  Layers,
  Zap,
  HelpCircle
} from 'lucide-react';

interface LandingViewProps {
  onLaunchDashboard: () => void;
  onExploreDemo: () => void;
  isLoadingDemo: boolean;
}

export const LandingView: React.FC<LandingViewProps> = ({
  onLaunchDashboard,
  onExploreDemo,
  isLoadingDemo,
}) => {
  return (
    <div className="space-y-16 pb-20">
      
      {/* Hero Section */}
      <section className="relative pt-12 pb-8 overflow-hidden text-center">
        <div className="absolute inset-0 pointer-events-none flex items-center justify-center opacity-40">
          <div className="w-[600px] h-[600px] rounded-full bg-gradient-to-tr from-sky-400/15 to-indigo-500/15 blur-3xl"></div>
        </div>

        <div className="relative max-w-4xl mx-auto px-4 sm:px-6">
          <div className="inline-flex items-center space-x-2 px-3.5 py-1.5 rounded-full bg-blue-50 border border-blue-200 text-blue-700 text-xs font-semibold mb-6 shadow-sm">
            <Sparkles className="w-3.5 h-3.5 text-blue-600" />
            <span>Next-Gen Paid Search Optimization Platform</span>
          </div>

          <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-slate-900 leading-tight">
            Stop Guessing. <br className="hidden sm:inline" />
            <span className="bg-gradient-to-r from-blue-600 via-indigo-600 to-sky-600 bg-clip-text text-transparent">
              Start Optimizing.
            </span>
          </h1>

          <p className="mt-6 text-lg sm:text-xl text-slate-600 max-w-2xl mx-auto leading-relaxed">
            AI-powered search term triage that turns thousands of Google Ads queries into explainable, actionable decisions.
          </p>

          {/* Action CTAs */}
          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
            <button
              onClick={onLaunchDashboard}
              className="w-full sm:w-auto px-6 py-3.5 rounded-xl font-semibold text-sm bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white shadow-lg shadow-blue-500/25 flex items-center justify-center space-x-2 transition-all active:scale-95"
            >
              <span>Launch Dashboard</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={onExploreDemo}
              disabled={isLoadingDemo}
              className="w-full sm:w-auto px-6 py-3.5 rounded-xl font-semibold text-sm bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 hover:border-blue-400 flex items-center justify-center space-x-2 shadow-sm transition-all"
            >
              <Sparkles className="w-4 h-4 text-blue-600" />
              <span>{isLoadingDemo ? 'Analyzing...' : 'Explore Sample Data'}</span>
            </button>
          </div>

          {/* Core Triage Triad Pills */}
          <div className="mt-12 flex flex-wrap items-center justify-center gap-3">
            <div className="flex items-center space-x-2 px-3.5 py-1.5 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold shadow-sm">
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              <span>PROMOTE: High-potential keywords to scale</span>
            </div>
            <div className="flex items-center space-x-2 px-3.5 py-1.5 rounded-lg bg-rose-50 border border-rose-200 text-rose-800 text-xs font-semibold shadow-sm">
              <span className="w-2 h-2 rounded-full bg-rose-500"></span>
              <span>BLOCK: Irrelevant queries to stop budget bleed</span>
            </div>
            <div className="flex items-center space-x-2 px-3.5 py-1.5 rounded-lg bg-amber-50 border border-amber-200 text-amber-800 text-xs font-semibold shadow-sm">
              <span className="w-2 h-2 rounded-full bg-amber-500"></span>
              <span>IGNORE: Statistically insufficient evidence</span>
            </div>
          </div>
        </div>
      </section>

      {/* Interactive Simulation Showcase */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="relative rounded-2xl p-1 bg-gradient-to-b from-blue-200 via-slate-200 to-slate-100 shadow-xl">
          <div className="rounded-[14px] bg-white p-6 sm:p-8 space-y-6">
            
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-100 gap-3">
              <div>
                <span className="text-xs uppercase font-mono tracking-wider text-blue-600 font-bold">Real-Time Triage Simulation</span>
                <h3 className="text-xl font-bold text-slate-900">How SearchPilot Prevents the "Single-Conversion Trap"</h3>
              </div>
              <span className="text-xs px-2.5 py-1 rounded bg-slate-50 border border-slate-200 text-slate-600 font-mono">
                Statistical Rigor vs Blind Rules
              </span>
            </div>

            {/* Simulated Query Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              
              {/* Card 1: Single Conversion Trap */}
              <div className="p-4 rounded-xl bg-amber-50/50 border border-amber-200 space-y-3 shadow-sm">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-mono text-amber-800 px-2 py-0.5 rounded bg-amber-100 border border-amber-200 font-bold">
                    IGNORE / REVIEW
                  </span>
                  <span className="text-xs font-mono text-slate-500">Clicks: 1 | Conv: 1</span>
                </div>
                <p className="text-sm font-semibold text-slate-900">"celebrity marathon finish line footwear"</p>
                <div className="text-xs text-slate-600 space-y-1">
                  <p><span className="text-slate-800 font-medium">Point CVR:</span> 100% (Naive rule trap)</p>
                  <p><span className="text-slate-800 font-medium">Wilson 95% Bound:</span> 20.6%</p>
                  <p className="text-amber-800 italic text-[11px] bg-amber-100/60 p-2 rounded">
                    "Single-conversion volatility. Sample size (N=1) lacks statistical power. Held in review."
                  </p>
                </div>
              </div>

              {/* Card 2: Valid High-Volume Promoter */}
              <div className="p-4 rounded-xl bg-emerald-50/50 border border-emerald-200 space-y-3 shadow-sm">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-mono text-emerald-800 px-2 py-0.5 rounded bg-emerald-100 border border-emerald-200 font-bold">
                    PROMOTE
                  </span>
                  <span className="text-xs font-mono text-slate-500">Clicks: 65 | Conv: 9</span>
                </div>
                <p className="text-sm font-semibold text-slate-900">"best marathon racing shoes carbon plate"</p>
                <div className="text-xs text-slate-600 space-y-1">
                  <p><span className="text-slate-800 font-medium">CVR:</span> 13.8% | <span className="text-slate-800 font-medium">ROAS:</span> 6.05x</p>
                  <p><span className="text-slate-800 font-medium">Confidence:</span> 94.2%</p>
                  <p className="text-emerald-800 italic text-[11px] bg-emerald-100/60 p-2 rounded">
                    "High intent + proven economic value. Ready for deliberate exact match targeting."
                  </p>
                </div>
              </div>

              {/* Card 3: Clear Irrelevant Negative */}
              <div className="p-4 rounded-xl bg-rose-50/50 border border-rose-200 space-y-3 shadow-sm">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-mono text-rose-800 px-2 py-0.5 rounded bg-rose-100 border border-rose-200 font-bold">
                    BLOCK
                  </span>
                  <span className="text-xs font-mono text-slate-500">Cost: $43.50 | Conv: 0</span>
                </div>
                <p className="text-sm font-semibold text-slate-900">"running shoes 3d model free download"</p>
                <div className="text-xs text-slate-600 space-y-1">
                  <p><span className="text-slate-800 font-medium">Detected Token:</span> 'free download'</p>
                  <p><span className="text-slate-800 font-medium">Confidence:</span> 96.0%</p>
                  <p className="text-rose-800 italic text-[11px] bg-rose-100/60 p-2 rounded">
                    "Negative intent identified. Recommend adding '\"free download\"' to negative lists."
                  </p>
                </div>
              </div>

            </div>

          </div>
        </div>
      </section>

      {/* Feature Pillars */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="text-center mb-12">
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900">Engineered for Enterprise Decision Quality</h2>
          <p className="text-slate-500 text-sm mt-2">Transparent heuristics and statistical rigor instead of black-box hype.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          
          <div className="p-6 rounded-2xl bg-white border border-slate-200 space-y-3 shadow-sm hover:border-blue-400 hover:shadow-md transition-all">
            <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
              <BrainCircuit className="w-5 h-5" />
            </div>
            <h4 className="text-base font-semibold text-slate-900">Smart Classification</h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Differentiates commercial high-intent buyers from job seekers, customer support searchers, and freebie hunters.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-white border border-slate-200 space-y-3 shadow-sm hover:border-indigo-400 hover:shadow-md transition-all">
            <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
              <TrendingUp className="w-5 h-5" />
            </div>
            <h4 className="text-base font-semibold text-slate-900">Statistical Uncertainty</h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Wilson score intervals prevent false positives on low-click queries. We never blindly promote on 1 conversion.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-white border border-slate-200 space-y-3 shadow-sm hover:border-purple-400 hover:shadow-md transition-all">
            <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
              <FileCheck2 className="w-5 h-5" />
            </div>
            <h4 className="text-base font-semibold text-slate-900">Explainable AI</h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Every single recommendation produces human-readable rationales, factor weights, and missing data alerts.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-white border border-slate-200 space-y-3 shadow-sm hover:border-emerald-400 hover:shadow-md transition-all">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <SlidersHorizontal className="w-5 h-5" />
            </div>
            <h4 className="text-base font-semibold text-slate-900">Human-in-the-Loop</h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              Dedicated review queues allow marketing analysts to verify, revise, add notes, and log audit decisions with full control.
            </p>
          </div>

        </div>
      </section>

      {/* 3-Step Workflow */}
      <section className="max-w-5xl mx-auto px-4 sm:px-6">
        <div className="p-8 rounded-2xl bg-white border border-blue-100 shadow-md">
          <div className="text-center mb-8">
            <span className="text-xs font-mono text-blue-600 uppercase tracking-widest font-bold">Workflow</span>
            <h3 className="text-xl font-bold text-slate-900 mt-1">From Raw Search Report to Optimized Campaigns</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 relative">
            
            <div className="text-center space-y-3">
              <div className="w-12 h-12 rounded-full bg-blue-50 text-blue-700 border border-blue-200 flex items-center justify-center mx-auto text-sm font-bold font-mono">
                01
              </div>
              <h5 className="font-semibold text-slate-900 text-sm">Upload Google Ads CSV</h5>
              <p className="text-xs text-slate-600">
                Drag-and-drop export file. Auto-detects columns, validates formatting, and previews 10 sample rows.
              </p>
            </div>

            <div className="text-center space-y-3">
              <div className="w-12 h-12 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200 flex items-center justify-center mx-auto text-sm font-bold font-mono">
                02
              </div>
              <h5 className="font-semibold text-slate-900 text-sm">Vectorized AI Triage</h5>
              <p className="text-xs text-slate-600">
                Processes up to 25,000 queries in seconds, computing statistical confidence, intent alignment, and economic value.
              </p>
            </div>

            <div className="text-center space-y-3">
              <div className="w-12 h-12 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center justify-center mx-auto text-sm font-bold font-mono">
                03
              </div>
              <h5 className="font-semibold text-slate-900 text-sm">Review & Export</h5>
              <p className="text-xs text-slate-600">
                Inspect recommendations in the Explorer, triage edge cases, and download Google Ads ready negative keyword files.
              </p>
            </div>

          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="max-w-6xl mx-auto px-4 sm:px-6 pt-10 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-4">
        <div className="flex items-center space-x-2">
          <Compass className="w-4 h-4 text-blue-600" />
          <span className="font-semibold text-slate-700">SearchPilot AI</span>
          <span>— Turn Search Data Into Smarter Decisions.</span>
        </div>
        <div className="flex items-center space-x-6 text-slate-500">
          <span>Google Ads Triage Engine</span>
          <span>Enterprise Edition</span>
        </div>
      </footer>

    </div>
  );
};
