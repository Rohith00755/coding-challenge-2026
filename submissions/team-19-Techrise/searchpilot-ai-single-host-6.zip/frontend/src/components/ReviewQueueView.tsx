import React, { useState, useEffect } from 'react';
import { 
  CheckCircle2, 
  ShieldAlert, 
  AlertCircle, 
  History, 
  Save, 
  Eye, 
  RefreshCw, 
  FileText, 
  UserCheck, 
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { SearchTermItem, TriageAction, AuditLogItem } from '../types';
import { api } from '../services/api';

interface ReviewQueueViewProps {
  datasetId?: string;
  onSelectTerm: (term: SearchTermItem) => void;
}

export const ReviewQueueView: React.FC<ReviewQueueViewProps> = ({ datasetId, onSelectTerm }) => {
  const [reviewItems, setReviewItems] = useState<SearchTermItem[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogItem[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'queue' | 'history'>('queue');

  // Active review form state
  const [activeTerm, setActiveTerm] = useState<SearchTermItem | null>(null);
  const [actionChoice, setActionChoice] = useState<TriageAction>('IGNORE');
  const [notes, setNotes] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  const loadData = async () => {
    setIsLoading(true);
    try {
      const [resTerms, resLogs] = await Promise.all([
        api.getResults({ datasetId, needsReview: true, pageSize: 50 }),
        api.getAuditLogs()
      ]);
      setReviewItems(resTerms.items || []);
      setAuditLogs(resLogs.logs || []);
      if (resTerms.items && resTerms.items.length > 0 && !activeTerm) {
        setActiveTerm(resTerms.items[0]);
        setActionChoice(resTerms.items[0].action);
        setNotes(resTerms.items[0].reviewer_notes || '');
      }
    } catch (err) {
      console.error('Failed to load review queue:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [datasetId]);

  const handleSelectToReview = (term: SearchTermItem) => {
    setActiveTerm(term);
    setActionChoice(term.action);
    setNotes(term.reviewer_notes || '');
  };

  const handleSaveReview = async () => {
    if (!activeTerm) return;
    setIsSubmitting(true);
    try {
      await api.reviewTerm(activeTerm.id, actionChoice, notes);
      setReviewItems((prev) => prev.filter((item) => item.id !== activeTerm.id));
      const logsRes = await api.getAuditLogs();
      setAuditLogs(logsRes.logs || []);
      const remaining = reviewItems.filter((item) => item.id !== activeTerm.id);
      if (remaining.length > 0) {
        setActiveTerm(remaining[0]);
        setActionChoice(remaining[0].action);
        setNotes('');
      } else {
        setActiveTerm(null);
      }
    } catch (err) {
      console.error('Failed to submit review:', err);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6 pb-16">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-2 border-b border-slate-200 gap-4">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 tracking-tight flex items-center space-x-2">
            <span>Human-in-the-Loop Review Center</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-50 text-amber-800 border border-amber-200 font-mono font-bold">
              {reviewItems.length} Pending
            </span>
          </h2>
          <p className="text-slate-500 text-xs mt-1">
            Prioritize queries with statistical ambiguity, low sample sizes (e.g. single-conversion trap), or conflicting intent.
          </p>
        </div>

        {/* Tab switcher */}
        <div className="flex items-center space-x-2 bg-white p-1 rounded-xl border border-slate-200 text-xs shadow-sm">
          <button
            onClick={() => setActiveTab('queue')}
            className={`px-3 py-1.5 rounded-lg font-semibold transition-all ${
              activeTab === 'queue' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Review Queue ({reviewItems.length})
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`px-3 py-1.5 rounded-lg font-semibold transition-all ${
              activeTab === 'history' ? 'bg-blue-600 text-white shadow-sm' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Audit Trail ({auditLogs.length})
          </button>
        </div>
      </div>

      {activeTab === 'queue' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Left Column: List of items needing review */}
          <div className="lg:col-span-5 space-y-3">
            <h3 className="text-xs font-bold text-slate-600 uppercase tracking-wider">
              Queries Requiring Analyst Decision
            </h3>

            {isLoading ? (
              <div className="p-8 text-center text-slate-500 bg-white rounded-xl border border-slate-200">
                <RefreshCw className="w-5 h-5 mx-auto animate-spin text-blue-600 mb-2" />
                <span>Loading queue...</span>
              </div>
            ) : reviewItems.length === 0 ? (
              <div className="p-8 text-center rounded-xl bg-white border border-slate-200 text-slate-600 space-y-2 shadow-sm">
                <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto" />
                <p className="font-bold text-slate-900">Review Queue is Empty!</p>
                <p className="text-xs text-slate-500">All ambiguous queries in this dataset have been resolved.</p>
              </div>
            ) : (
              <div className="space-y-2.5 max-h-[620px] overflow-y-auto pr-1">
                {reviewItems.map((term) => {
                  const isSelected = activeTerm?.id === term.id;
                  return (
                    <div
                      key={term.id}
                      onClick={() => handleSelectToReview(term)}
                      className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                        isSelected
                          ? 'bg-blue-50/70 border-blue-400 shadow-sm'
                          : 'bg-white border-slate-200 hover:border-slate-300 shadow-sm'
                      }`}
                    >
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span className="font-mono text-[11px] text-slate-500">{term.campaign}</span>
                        <span className={`text-[10px] font-bold px-1.5 py-0.2 rounded font-mono ${
                          term.action === 'PROMOTE' ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' :
                          term.action === 'BLOCK' ? 'bg-rose-50 text-rose-800 border border-rose-200' :
                          'bg-amber-50 text-amber-800 border border-amber-200'
                        }`}>
                          {term.action} ({term.confidence}%)
                        </span>
                      </div>
                      <p className="text-xs font-bold text-slate-900 truncate" title={term.query}>
                        "{term.query}"
                      </p>
                      <div className="flex items-center space-x-3 text-[11px] text-slate-600 mt-2">
                        <span>Clicks: <b className="text-slate-900">{term.clicks}</b></span>
                        <span>Spend: <b className="text-slate-900">${term.cost.toFixed(2)}</b></span>
                        <span>Conv: <b className="text-emerald-700">{term.conversions}</b></span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Right Column: Detailed review workbench */}
          <div className="lg:col-span-7">
            {activeTerm ? (
              <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-6">
                
                {/* Header */}
                <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                  <div>
                    <span className="text-[10px] font-mono uppercase text-blue-600 font-bold">Analyst Inspection</span>
                    <h3 className="text-lg font-bold text-slate-900">"{activeTerm.query}"</h3>
                  </div>
                  <button
                    onClick={() => onSelectTerm(activeTerm)}
                    className="flex items-center space-x-1 text-xs text-blue-600 hover:text-blue-700 font-semibold"
                  >
                    <span>Inspect Raw Model</span>
                    <Eye className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Metrics ribbon */}
                <div className="grid grid-cols-4 gap-3 bg-slate-50 p-3 rounded-xl border border-slate-200 text-center">
                  <div>
                    <span className="text-[10px] text-slate-500">Clicks</span>
                    <p className="text-xs font-mono font-bold text-slate-900">{activeTerm.clicks}</p>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500">Cost</span>
                    <p className="text-xs font-mono font-bold text-slate-900">${activeTerm.cost.toFixed(2)}</p>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500">Conversions</span>
                    <p className="text-xs font-mono font-bold text-emerald-700">{activeTerm.conversions}</p>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500">Confidence</span>
                    <p className="text-xs font-mono font-bold text-amber-700">{activeTerm.confidence}%</p>
                  </div>
                </div>

                {/* Algorithmic Reason */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-800">Algorithmic Triage Rationale:</label>
                  <p className="text-xs text-slate-700 bg-slate-50 p-3 rounded-xl border border-slate-200 leading-relaxed font-sans">
                    {activeTerm.reason}
                  </p>
                </div>

                {/* Missing Data Needed */}
                {activeTerm.missing_info && (
                  <div className="space-y-1.5">
                    <label className="text-xs font-bold text-amber-900">Statistical Boundary / Missing Data:</label>
                    <p className="text-xs text-amber-900 bg-amber-50 p-3 rounded-xl border border-amber-200">
                      {activeTerm.missing_info}
                    </p>
                  </div>
                )}

                {/* Action Override Selector */}
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-800">Set Final Decision:</label>
                  <div className="grid grid-cols-3 gap-3">
                    <button
                      type="button"
                      onClick={() => setActionChoice('PROMOTE')}
                      className={`py-2.5 px-3 rounded-xl text-xs font-bold transition-all ${
                        actionChoice === 'PROMOTE'
                          ? 'bg-emerald-600 text-white shadow-md'
                          : 'bg-slate-50 border border-slate-200 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      PROMOTE
                    </button>
                    <button
                      type="button"
                      onClick={() => setActionChoice('BLOCK')}
                      className={`py-2.5 px-3 rounded-xl text-xs font-bold transition-all ${
                        actionChoice === 'BLOCK'
                          ? 'bg-rose-600 text-white shadow-md'
                          : 'bg-slate-50 border border-slate-200 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      BLOCK
                    </button>
                    <button
                      type="button"
                      onClick={() => setActionChoice('IGNORE')}
                      className={`py-2.5 px-3 rounded-xl text-xs font-bold transition-all ${
                        actionChoice === 'IGNORE'
                          ? 'bg-amber-600 text-white shadow-md'
                          : 'bg-slate-50 border border-slate-200 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      IGNORE / MONITOR
                    </button>
                  </div>
                </div>

                {/* Reviewer Notes Input */}
                <div className="space-y-1.5">
                  <label className="text-xs font-bold text-slate-800">Analyst Justification Notes:</label>
                  <textarea
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Provide context for your team (e.g. 'Single conversion was an anomaly, blocking because product is out of stock')..."
                    rows={3}
                    className="w-full text-xs bg-slate-50 border border-slate-200 rounded-xl p-3 text-slate-900 placeholder-slate-400 focus:outline-none focus:border-blue-500 focus:bg-white shadow-sm"
                  />
                </div>

                {/* Submit button */}
                <button
                  onClick={handleSaveReview}
                  disabled={isSubmitting}
                  className="w-full py-3 rounded-xl font-semibold text-xs bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white flex items-center justify-center space-x-2 shadow-md shadow-blue-500/20 transition-all disabled:opacity-50"
                >
                  <Save className="w-4 h-4" />
                  <span>{isSubmitting ? 'Recording Decision...' : 'Commit Analyst Decision & Advance'}</span>
                </button>

              </div>
            ) : (
              <div className="p-12 text-center rounded-2xl bg-white border border-slate-200 text-slate-400 shadow-sm">
                Select a query from the left queue to review.
              </div>
            )}
          </div>

        </div>
      ) : (
        /* History / Audit Log View */
        <div className="rounded-2xl bg-white border border-slate-200 overflow-hidden shadow-sm">
          <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50">
            <h4 className="text-sm font-bold text-slate-900">Reviewer Audit Trail</h4>
            <span className="text-xs text-slate-500 font-mono">{auditLogs.length} Logged Actions</span>
          </div>

          <div className="divide-y divide-slate-100 max-h-[600px] overflow-y-auto">
            {auditLogs.length === 0 ? (
              <div className="p-8 text-center text-slate-400 text-xs">
                No human review actions have been committed yet in this session.
              </div>
            ) : (
              auditLogs.map((log) => (
                <div key={log.id} className="p-4 hover:bg-slate-50 transition-colors space-y-1.5 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900">"{log.query}"</span>
                    <span className="text-[10px] text-slate-500 font-mono">
                      {new Date(log.timestamp).toLocaleTimeString()}
                    </span>
                  </div>
                  <div className="flex items-center space-x-2 text-[11px]">
                    <span className="text-slate-500">Changed from</span>
                    <span className="font-mono font-bold text-slate-700">{log.old_action}</span>
                    <ArrowRight className="w-3 h-3 text-blue-600" />
                    <span className="font-mono font-bold text-emerald-700">{log.new_action}</span>
                  </div>
                  {log.notes && (
                    <p className="text-[11px] text-slate-600 italic bg-slate-50 p-2 rounded border border-slate-100">
                      "{log.notes}"
                    </p>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      )}

    </div>
  );
};
