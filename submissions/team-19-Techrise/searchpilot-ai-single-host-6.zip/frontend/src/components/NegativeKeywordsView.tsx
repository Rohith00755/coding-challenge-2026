import React, { useState, useEffect } from 'react';
import { 
  ShieldAlert, 
  Download, 
  Search, 
  Copy, 
  Check, 
  RefreshCw
} from 'lucide-react';
import { NegativeKeywordItem } from '../types';
import { api } from '../services/api';

interface NegativeKeywordsViewProps {
  datasetId?: string;
}

export const NegativeKeywordsView: React.FC<NegativeKeywordsViewProps> = ({ datasetId }) => {
  const [negatives, setNegatives] = useState<NegativeKeywordItem[]>([]);
  const [totalWaste, setTotalWaste] = useState<number>(0);
  const [search, setSearch] = useState<string>('');
  const [matchFilter, setMatchFilter] = useState<string>('ALL');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [copiedId, setCopiedId] = useState<number | null>(null);

  const fetchNegatives = async () => {
    setIsLoading(true);
    try {
      const res = await api.getNegativeKeywords(datasetId);
      setNegatives(res.items || []);
      setTotalWaste(res.total_estimated_waste || 0);
    } catch (err) {
      console.error('Failed to fetch negative keywords:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchNegatives();
  }, [datasetId]);

  const handleCopy = (id: number, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const filteredNegatives = negatives.filter((item) => {
    const matchesSearch = item.keyword.toLowerCase().includes(search.toLowerCase()) ||
      item.campaign.toLowerCase().includes(search.toLowerCase()) ||
      item.reason.toLowerCase().includes(search.toLowerCase());
    const matchesType = matchFilter === 'ALL' || item.match_type.toUpperCase() === matchFilter.toUpperCase();
    return matchesSearch && matchesType;
  });

  return (
    <div className="space-y-6 pb-16">
      
      {/* Header and Savings Callout */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-rose-50 via-white to-rose-50 border border-rose-200 flex flex-col md:flex-row md:items-center justify-between gap-6 shadow-sm">
        <div className="space-y-1">
          <div className="flex items-center space-x-2">
            <ShieldAlert className="w-5 h-5 text-rose-600" />
            <h2 className="text-xl font-bold text-slate-900 tracking-tight">Negative Keyword Management Studio</h2>
          </div>
          <p className="text-xs text-slate-600 max-w-2xl leading-relaxed">
            Eliminate wasted ad spend with automated negative keyword syntax, collision protection, and Google Ads Editor compatibility.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
          <div className="p-3 rounded-xl bg-white border border-rose-200 text-right shadow-sm">
            <span className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold">Historical Waste Eliminated</span>
            <div className="text-xl font-bold text-rose-600 font-mono">
              ${totalWaste.toFixed(2)}
            </div>
          </div>

          <a
            href={api.getExportNegativesUrl(datasetId)}
            download
            className="px-4 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-semibold text-xs flex items-center space-x-2 shadow-md shadow-rose-500/20 active:scale-95 transition-all"
          >
            <Download className="w-4 h-4" />
            <span>Download Google Ads Format</span>
          </a>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-xl bg-white border border-slate-200 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4">
        
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-2.5" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Filter negatives or campaigns..."
            className="w-full pl-10 pr-4 py-1.5 rounded-lg bg-slate-50 border border-slate-200 text-xs text-slate-900 placeholder-slate-400 focus:outline-none focus:border-rose-500 focus:bg-white"
          />
        </div>

        <div className="flex items-center space-x-2 text-xs">
          <span className="text-slate-600 font-medium">Match Type:</span>
          {['ALL', 'EXACT', 'PHRASE'].map((t) => (
            <button
              key={t}
              onClick={() => setMatchFilter(t)}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all ${
                matchFilter === t
                  ? 'bg-rose-100 text-rose-800 border border-rose-300 font-bold'
                  : 'bg-white text-slate-600 border border-slate-200 hover:text-slate-900'
              }`}
            >
              {t}
            </button>
          ))}
        </div>

        <span className="text-xs text-slate-500 font-mono">
          Showing {filteredNegatives.length} candidate keywords
        </span>

      </div>

      {/* Negatives Table */}
      <div className="rounded-2xl bg-white border border-slate-200 overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-mono text-[11px]">
                <th className="py-3 px-4 font-semibold">Suggested Negative Syntax</th>
                <th className="py-3 px-3 font-semibold text-center">Match Type</th>
                <th className="py-3 px-3 font-semibold text-center">Recommended Scope</th>
                <th className="py-3 px-3 font-semibold">Campaign / Target</th>
                <th className="py-3 px-3 font-semibold text-right">Potential Spend Saved</th>
                <th className="py-3 px-4 font-semibold">Collision & Safety Rationale</th>
                <th className="py-3 px-3 text-center">Copy</th>
              </tr>
            </thead>

            <tbody className="divide-y divide-slate-100">
              {isLoading ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-500">
                    <RefreshCw className="w-6 h-6 mx-auto animate-spin text-rose-600 mb-2" />
                    <span>Loading negative keywords...</span>
                  </td>
                </tr>
              ) : filteredNegatives.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-slate-500">
                    No negative keywords found in this view.
                  </td>
                </tr>
              ) : (
                filteredNegatives.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-50/70 transition-colors">
                    
                    {/* Keyword Syntax */}
                    <td className="py-3 px-4 font-mono font-bold text-rose-700 text-sm">
                      {item.keyword}
                    </td>

                    {/* Match Type */}
                    <td className="py-3 px-3 text-center">
                      <span className="px-2 py-0.5 rounded text-[11px] font-mono bg-slate-100 text-slate-700 border border-slate-200 font-medium">
                        {item.match_type}
                      </span>
                    </td>

                    {/* Scope */}
                    <td className="py-3 px-3 text-center">
                      <span className={`px-2 py-0.5 rounded text-[11px] font-mono font-bold ${
                        item.scope === 'Campaign' ? 'bg-indigo-50 text-indigo-700 border border-indigo-200' : 'bg-blue-50 text-blue-700 border border-blue-200'
                      }`}>
                        {item.scope}
                      </span>
                    </td>

                    {/* Campaign */}
                    <td className="py-3 px-3 text-slate-700 max-w-[180px] truncate">
                      <div className="font-semibold text-slate-900">{item.campaign}</div>
                      {item.ad_group && (
                        <div className="text-[10px] text-slate-500">{item.ad_group}</div>
                      )}
                    </td>

                    {/* Potential Spend */}
                    <td className="py-3 px-3 text-right font-mono font-bold text-rose-700">
                      ${item.estimated_waste.toFixed(2)}
                    </td>

                    {/* Reason */}
                    <td className="py-3 px-4 text-slate-600 text-[11px] max-w-[320px]">
                      {item.reason}
                    </td>

                    {/* Copy Button */}
                    <td className="py-3 px-3 text-center">
                      <button
                        onClick={() => handleCopy(item.id, item.keyword)}
                        className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 hover:text-slate-900 transition-all shadow-sm"
                        title="Copy to clipboard"
                      >
                        {copiedId === item.id ? (
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </td>

                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
