import React, { useState, useRef } from 'react';
import { 
  UploadCloud, 
  FileSpreadsheet, 
  CheckCircle2, 
  AlertTriangle, 
  Download, 
  Sparkles, 
  Zap, 
  ArrowRight,
  RefreshCw,
  Sliders,
  Check
} from 'lucide-react';
import { api } from '../services/api';

interface UploadCenterViewProps {
  onDatasetLoaded: (datasetId: string, datasetName: string) => void;
  onExploreDemo: () => void;
  isLoadingDemo: boolean;
}

export const UploadCenterView: React.FC<UploadCenterViewProps> = ({
  onDatasetLoaded,
  onExploreDemo,
  isLoadingDemo
}) => {
  const [dragActive, setDragActive] = useState<boolean>(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploadResult, setUploadResult] = useState<any | null>(null);
  const [isUploading, setIsUploading] = useState<boolean>(false);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [targetCpa, setTargetCpa] = useState<number>(35.0);
  const [targetRoas, setTargetRoas] = useState<number>(3.0);

  // Stress test states
  const [isStressTesting, setIsStressTesting] = useState<boolean>(false);
  const [stressResult, setStressResult] = useState<any | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };

  const handleFile = async (file: File) => {
    if (!/\.(csv|tsv|txt)$/i.test(file.name)) {
      setErrorMsg('Invalid file type: Please upload a Google Ads CSV (.csv) export.');
      return;
    }
    setErrorMsg(null);
    setUploadResult(null);
    setSelectedFile(file);
    setIsUploading(true);
    try {
      const res = await api.uploadCsv(file);
      setUploadResult(res);
    } catch (err: any) {
      setUploadResult(null);
      setErrorMsg(err.message || 'Failed to upload and validate CSV file.');
    } finally {
      setIsUploading(false);
      // allow re-selecting the same file after a failure
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleRunAnalysis = async () => {
    if (!uploadResult || !selectedFile) return;
    setIsAnalyzing(true);
    setErrorMsg(null);
    try {
      await api.analyzeDataset(uploadResult.dataset_id, targetCpa, targetRoas);
      onDatasetLoaded(uploadResult.dataset_id, selectedFile.name);
    } catch (err: any) {
      setErrorMsg(err.message || 'Analysis pipeline failed.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleRunStressTest = async () => {
    setIsStressTesting(true);
    setStressResult(null);
    try {
      const res = await api.runStressTest();
      setStressResult(res);
    } catch (err) {
      console.error(err);
    } finally {
      setIsStressTesting(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8 pb-16">
      
      {/* Title */}
      <div className="text-center space-y-2">
        <h2 className="text-3xl font-bold text-slate-900 tracking-tight">Data Upload & Ingestion Center</h2>
        <p className="text-slate-600 text-sm max-w-xl mx-auto">
          Upload any Google Ads search term report. SearchPilot auto-detects column names, validates statistical thresholds, and handles up to 25,000 rows.
        </p>
      </div>

      {/* Sample dataset bar */}
      <div className="p-4 rounded-xl bg-blue-50/70 border border-blue-200 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-sm">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center">
            <Sparkles className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-slate-900">Quick Start</h4>
            <p className="text-[11px] text-slate-600">Want to try it right away? Load a ready-made multi-campaign sample dataset.</p>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={onExploreDemo}
            disabled={isLoadingDemo}
            className="flex items-center space-x-1.5 px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white text-xs font-semibold shadow-md shadow-blue-500/20 transition-all disabled:opacity-50"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{isLoadingDemo ? 'Analyzing...' : 'Load Sample Data'}</span>
          </button>
        </div>
      </div>

      {/* Drag & Drop Upload Card */}
      <div
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
        className={`p-10 rounded-2xl border-2 border-dashed text-center cursor-pointer transition-all ${
          dragActive
            ? 'border-blue-500 bg-blue-50/50 shadow-md'
            : 'border-slate-300 hover:border-blue-400 bg-white hover:bg-slate-50/50 shadow-sm'
        }`}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept=".csv,.tsv,.txt,text/csv"
          onChange={handleFileInput}
          className="hidden"
        />

        <div className="max-w-md mx-auto space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto border border-blue-200">
            {isUploading ? (
              <RefreshCw className="w-7 h-7 animate-spin text-blue-600" />
            ) : (
              <UploadCloud className="w-7 h-7" />
            )}
          </div>

          <div>
            <h3 className="text-base font-bold text-slate-900">
              {selectedFile ? selectedFile.name : 'Drag & drop Google Ads Search Terms CSV'}
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Supports standard Google Ads exports. Auto-maps columns: Search term, Match type, Impressions, Clicks, Cost, Conversions.
            </p>
          </div>

          <button
            type="button"
            className="px-4 py-2 rounded-lg bg-white hover:bg-slate-50 text-xs font-semibold text-slate-700 border border-slate-300 shadow-sm"
          >
            Browse Local File
          </button>
        </div>
      </div>

      {/* Error Banner */}
      {errorMsg && (
        <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center space-x-2">
          <AlertTriangle className="w-4 h-4 text-rose-600 flex-shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* File Preview and Parameter Configuration */}
      {uploadResult && (
        <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-6">
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
            <div>
              <div className="flex items-center space-x-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                <h4 className="text-sm font-bold text-slate-900">File Validated & Auto-Mapped</h4>
              </div>
              <p className="text-xs text-slate-500 mt-0.5 font-mono">
                {uploadResult.filename} • {uploadResult.row_count.toLocaleString()} valid query rows detected{uploadResult.skipped_rows > 0 ? ` (${uploadResult.skipped_rows} total/blank rows skipped)` : ''}
              </p>
            </div>

            {/* Economic Target Thresholds */}
            <div className="flex items-center space-x-3 text-xs">
              <div className="flex items-center space-x-1.5 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200">
                <span className="text-slate-600">Target CPA:</span>
                <span className="text-slate-400">$</span>
                <input
                  type="number"
                  value={targetCpa}
                  onChange={(e) => setTargetCpa(Number(e.target.value))}
                  className="w-14 bg-transparent text-slate-900 font-mono font-bold focus:outline-none"
                />
              </div>

              <div className="flex items-center space-x-1.5 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-200">
                <span className="text-slate-600">Target ROAS:</span>
                <input
                  type="number"
                  step="0.5"
                  value={targetRoas}
                  onChange={(e) => setTargetRoas(Number(e.target.value))}
                  className="w-12 bg-transparent text-slate-900 font-mono font-bold focus:outline-none"
                />
                <span className="text-slate-400">x</span>
              </div>
            </div>
          </div>

          {uploadResult.warnings && uploadResult.warnings.length > 0 && (
            <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 text-[11px] space-y-1">
              {uploadResult.warnings.map((w: string, i: number) => (
                <div key={i} className="flex items-start space-x-2">
                  <AlertTriangle className="w-3.5 h-3.5 mt-0.5 flex-shrink-0 text-amber-600" />
                  <span>{w}</span>
                </div>
              ))}
            </div>
          )}

          {/* 10-Row Table Preview */}
          <div className="space-y-2">
            <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              Preview First 10 Rows (Auto-Normalized Columns)
            </span>
            <div className="overflow-x-auto rounded-xl border border-slate-200">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-slate-50 text-slate-600 font-mono text-[11px]">
                  <tr>
                    <th className="py-2.5 px-3">Search Term</th>
                    <th className="py-2.5 px-3">Campaign</th>
                    <th className="py-2.5 px-2 text-right">Impr</th>
                    <th className="py-2.5 px-2 text-right">Clicks</th>
                    <th className="py-2.5 px-2 text-right">Cost</th>
                    <th className="py-2.5 px-2 text-right">Conv</th>
                    <th className="py-2.5 px-2 text-right">Conv. Value</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-mono text-[11px]">
                  {uploadResult.preview.map((r: any, idx: number) => (
                    <tr key={idx} className="hover:bg-slate-50">
                      <td className="py-2 px-3 text-slate-900 font-sans font-medium">{r.query}</td>
                      <td className="py-2 px-3 text-slate-600">{r.campaign}</td>
                      <td className="py-2 px-2 text-right text-slate-700">{r.impressions}</td>
                      <td className="py-2 px-2 text-right text-slate-700">{r.clicks}</td>
                      <td className="py-2 px-2 text-right text-slate-700">${Number(r.cost).toFixed(2)}</td>
                      <td className="py-2 px-2 text-right text-emerald-700 font-bold">{r.conversions}</td>
                      <td className="py-2 px-2 text-right text-blue-700 font-bold">${Number(r.conversion_value).toFixed(2)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Run Analysis CTA */}
          <button
            onClick={handleRunAnalysis}
            disabled={isAnalyzing}
            className="w-full py-3.5 rounded-xl font-bold text-sm bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white flex items-center justify-center space-x-2 shadow-md shadow-blue-500/20 transition-all disabled:opacity-50"
          >
            {isAnalyzing ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin text-white" />
                <span>Running Statistical & NLP Triage Pipeline...</span>
              </>
            ) : (
              <>
                <Zap className="w-4 h-4" />
                <span>Execute AI Search Term Triage Engine</span>
                <ArrowRight className="w-4 h-4 ml-1" />
              </>
            )}
          </button>

        </div>
      )}

      {/* 25,000 Rows High-Scale Benchmark Box */}
      <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Zap className="w-5 h-5 text-amber-500" />
            <div>
              <h4 className="text-sm font-bold text-slate-900">Large-Scale Processing Stress Test</h4>
              <p className="text-xs text-slate-500">
                Verify that SearchPilot analyzes 25,000 Google Ads rows in sub-2-second vectorized execution.
              </p>
            </div>
          </div>

          <button
            onClick={handleRunStressTest}
            disabled={isStressTesting}
            className="px-4 py-2 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-700 text-xs font-semibold border border-slate-300 transition-all disabled:opacity-50"
          >
            {isStressTesting ? 'Simulating 25,000 Rows...' : 'Run 25k Stress Test'}
          </button>
        </div>

        {stressResult && (
          <div className="p-4 rounded-xl bg-slate-50 border border-emerald-200 grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
            <div>
              <span className="text-[10px] text-slate-500 uppercase font-semibold">Rows Triaged</span>
              <p className="text-lg font-bold text-slate-900 font-mono">{stressResult.rows_processed.toLocaleString()}</p>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 uppercase font-semibold">Total Time</span>
              <p className="text-lg font-bold text-emerald-700 font-mono">{stressResult.execution_time_seconds}s</p>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 uppercase font-semibold">Throughput</span>
              <p className="text-lg font-bold text-blue-700 font-mono">{stressResult.throughput_rows_per_second} / sec</p>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 uppercase font-semibold">Outcome</span>
              <p className="text-xs font-bold text-emerald-700 font-mono mt-1">
                {stressResult.promote_count} Promoted | {stressResult.block_count} Blocked
              </p>
            </div>
          </div>
        )}
      </div>

    </div>
  );
};
