import React from 'react';
import { 
  Compass, 
  BarChart3, 
  Search, 
  ShieldAlert, 
  UploadCloud, 
  FileText, 
  Sparkles, 
  CheckCircle2,
  Bell,
  User,
  Sliders,
  FileSpreadsheet
} from 'lucide-react';

interface NavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  datasetName: string;
  onLoadDemo: () => void;
  isLoadingDemo: boolean;
  reviewNeededCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  setCurrentTab,
  datasetName,
  onLoadDemo,
  isLoadingDemo,
  reviewNeededCount
}) => {
  const navItems = [
    { id: 'landing', label: 'Overview', icon: Compass },
    { id: 'dashboard', label: 'Analytics Dashboard', icon: BarChart3 },
    { id: 'explorer', label: 'Search Term Explorer', icon: Search },
    { id: 'review', label: 'Review Queue', icon: CheckCircle2, badge: reviewNeededCount },
    { id: 'negatives', label: 'Negative Keywords', icon: ShieldAlert },
    { id: 'upload', label: 'Upload Center', icon: UploadCloud },
    { id: 'reports', label: 'Reports & Export', icon: FileText },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-blue-100 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo & Brand */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setCurrentTab('landing')}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center shadow-md shadow-blue-500/20">
              <Compass className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-xl font-bold tracking-tight text-slate-900">SearchPilot</span>
                <span className="text-xs px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-200 font-semibold font-mono">
                  AI v2.4
                </span>
              </div>
              <p className="text-[10px] text-slate-500 hidden sm:block tracking-wide">
                Google Ads Search Term Triage Engine
              </p>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="hidden lg:flex items-center space-x-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setCurrentTab(item.id)}
                  className={`relative flex items-center space-x-2 px-3 py-2 rounded-lg text-xs font-semibold transition-all ${
                    isActive
                      ? 'bg-blue-50 text-blue-700 border border-blue-200 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-blue-600' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                  {item.badge !== undefined && item.badge > 0 && (
                    <span className="ml-1.5 px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-200">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Action Buttons */}
          <div className="flex items-center space-x-3">
            <button
              onClick={onLoadDemo}
              disabled={isLoadingDemo}
              className="flex items-center space-x-2 px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white shadow-md shadow-blue-500/20 active:scale-95 transition-all disabled:opacity-50"
              title="Instantly load realistic Google Ads dataset"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>{isLoadingDemo ? 'Analyzing...' : 'Load Sample Data'}</span>
            </button>

            {/* Active Dataset Chip */}
            <div className="hidden xl:flex items-center space-x-2 px-2.5 py-1 rounded-md bg-blue-50 border border-blue-100 text-[11px] text-slate-700">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <span className="truncate max-w-[130px] font-mono">{datasetName}</span>
            </div>

            {/* User Profile Avatar */}
            <div className="w-8 h-8 rounded-lg bg-blue-100/70 border border-blue-200 flex items-center justify-center text-blue-800 text-xs font-bold">
              AD
            </div>
          </div>

        </div>
      </div>

      {/* Mobile navigation tab strip */}
      <div className="lg:hidden flex items-center space-x-1 px-4 py-2 overflow-x-auto border-t border-slate-200 bg-white">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setCurrentTab(item.id)}
              className={`flex items-center space-x-1.5 px-2.5 py-1.5 rounded-md text-xs whitespace-nowrap ${
                isActive ? 'bg-blue-50 text-blue-700 border border-blue-200 font-semibold' : 'text-slate-600'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{item.label}</span>
              {item.badge !== undefined && item.badge > 0 && (
                <span className="px-1 text-[9px] rounded-full bg-amber-100 text-amber-800">
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </header>
  );
};
