import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { LandingView } from './components/LandingView';
import { DashboardView } from './components/DashboardView';
import { ExplorerView } from './components/ExplorerView';
import { ExplanationDrawer } from './components/ExplanationDrawer';
import { ReviewQueueView } from './components/ReviewQueueView';
import { NegativeKeywordsView } from './components/NegativeKeywordsView';
import { UploadCenterView } from './components/UploadCenterView';
import { ReportsView } from './components/ReportsView';
import { api } from './services/api';
import { DashboardSummaryResponse, SearchTermItem, TriageAction } from './types';

export const App: React.FC = () => {
  const [currentTab, setCurrentTab] = useState<string>('landing');
  const [datasetId, setDatasetId] = useState<string>('');
  const [datasetName, setDatasetName] = useState<string>('No Dataset Loaded');
  const [summaryData, setSummaryData] = useState<DashboardSummaryResponse>({ has_data: false });
  const [selectedTerm, setSelectedTerm] = useState<SearchTermItem | null>(null);
  const [explorerFilter, setExplorerFilter] = useState<string>('ALL');
  const [isLoadingDemo, setIsLoadingDemo] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const refreshSummary = async (targetId?: string) => {
    try {
      const summary = await api.getSummary(targetId || datasetId);
      setSummaryData(summary);
      if (summary.has_data && summary.dataset_id) {
        setDatasetId(summary.dataset_id);
      }
    } catch (err) {
      console.error('Failed to load summary:', err);
    }
  };

  useEffect(() => {
    // Initial fetch to check if an analyzed dataset already exists
    api.getSummary().then((res) => {
      if (res && res.has_data && res.dataset_id) {
        setSummaryData(res);
        setDatasetId(res.dataset_id);
        setDatasetName(`Dataset: ${res.dataset_id}`);
      }
    });
  }, []);

  const handleLoadDemo = async () => {
    setIsLoadingDemo(true);
    try {
      const res = await api.loadDemo();
      setDatasetId(res.dataset_id);
      setDatasetName(res.dataset_name);
      await refreshSummary(res.dataset_id);
      showToast('Sample dataset loaded and analyzed successfully!');
      setCurrentTab('dashboard');
    } catch (err) {
      console.error('Failed to load demo:', err);
    } finally {
      setIsLoadingDemo(false);
    }
  };

  const handleDatasetLoaded = async (newId: string, filename: string) => {
    setDatasetId(newId);
    setDatasetName(filename);
    await refreshSummary(newId);
    showToast(`Dataset '${filename}' analyzed successfully!`);
    setCurrentTab('dashboard');
  };

  const handleDrawerReviewSubmit = async (termId: number, action: TriageAction, notes: string) => {
    try {
      await api.reviewTerm(termId, action, notes);
      showToast(`Term #${termId} recommendation updated to ${action}`);
      if (selectedTerm && selectedTerm.id === termId) {
        setSelectedTerm({
          ...selectedTerm,
          action,
          review_status: 'APPROVED',
          reviewer_notes: notes,
          needs_review: 0
        });
      }
      refreshSummary(datasetId);
    } catch (err) {
      console.error('Failed to submit review:', err);
    }
  };

  const handleNavigateTab = (tab: string, filter?: string) => {
    if (filter) {
      setExplorerFilter(filter);
    }
    setCurrentTab(tab);
  };

  return (
    <div className="min-h-screen bg-[#F4F8FC] text-slate-800 flex flex-col font-sans">
      
      {/* Top Navbar */}
      <Navbar
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        datasetName={datasetName}
        onLoadDemo={handleLoadDemo}
        isLoadingDemo={isLoadingDemo}
        reviewNeededCount={summaryData?.kpis?.review_needed_count || 0}
      />

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 px-4 py-2.5 rounded-xl bg-white border border-blue-200 text-blue-700 text-xs font-semibold shadow-xl flex items-center space-x-2 animate-bounce">
          <span className="w-2 h-2 rounded-full bg-blue-500"></span>
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Main View Router */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-6">
        {currentTab === 'landing' && (
          <LandingView
            onLaunchDashboard={() => setCurrentTab('dashboard')}
            onExploreDemo={handleLoadDemo}
            isLoadingDemo={isLoadingDemo}
          />
        )}

        {currentTab === 'dashboard' && (
          <DashboardView
            data={summaryData}
            onNavigateTab={handleNavigateTab}
          />
        )}

        {currentTab === 'explorer' && (
          <ExplorerView
            datasetId={datasetId}
            initialActionFilter={explorerFilter}
            onSelectTerm={(term) => setSelectedTerm(term)}
          />
        )}

        {currentTab === 'review' && (
          <ReviewQueueView
            datasetId={datasetId}
            onSelectTerm={(term) => setSelectedTerm(term)}
          />
        )}

        {currentTab === 'negatives' && (
          <NegativeKeywordsView
            datasetId={datasetId}
          />
        )}

        {currentTab === 'upload' && (
          <UploadCenterView
            onDatasetLoaded={handleDatasetLoaded}
            onExploreDemo={handleLoadDemo}
            isLoadingDemo={isLoadingDemo}
          />
        )}

        {currentTab === 'reports' && (
          <ReportsView
            data={summaryData}
          />
        )}
      </main>

      {/* Slide-out Explainable Recommendation Drawer */}
      {selectedTerm && (
        <ExplanationDrawer
          term={selectedTerm}
          onClose={() => setSelectedTerm(null)}
          onReviewSubmit={handleDrawerReviewSubmit}
        />
      )}

    </div>
  );
};
export default App;
