export type TriageAction = 'PROMOTE' | 'BLOCK' | 'IGNORE';
export type ReviewStatus = 'PENDING' | 'APPROVED' | 'REVISED';

export interface SearchTermItem {
  id: number;
  dataset_id: string;
  query: string;
  campaign: string;
  ad_group: string;
  match_type: string;
  impressions: number;
  clicks: number;
  cost: number;
  conversions: number;
  conversion_value: number;
  ctr: number;
  cvr: number;
  cpa: number;
  roas: number;
  cpc: number;
  action: TriageAction;
  confidence: number;
  reason: string;
  missing_info?: string;
  financial_impact?: string;
  needs_review: number;
  review_status: ReviewStatus;
  reviewer_action?: string;
  reviewer_notes?: string;
  updated_at?: string;
}

export interface SummaryKPIs {
  total_terms: number;
  promote_count: number;
  block_count: number;
  ignore_count: number;
  review_needed_count: number;
  reviewed_count: number;
  estimated_waste_saved: number;
  total_impressions: number;
  total_clicks: number;
  total_spend: number;
  total_conversions: number;
  total_conversion_value: number;
  avg_confidence: number;
  overall_roas: number;
}

export interface ConfidenceDistribution {
  high_conf: number;
  med_conf: number;
  low_conf: number;
}

export interface CampaignBreakdown {
  campaign: string;
  total: number;
  promote: number;
  block: number;
  ignore: number;
  spend: number;
  conversion_value: number;
}

export interface ActionEconomics {
  action: TriageAction;
  spend: number;
  conv_value: number;
}

export interface DashboardSummaryResponse {
  has_data: boolean;
  dataset_id?: string;
  kpis?: SummaryKPIs;
  confidence_distribution?: ConfidenceDistribution;
  campaign_breakdown?: CampaignBreakdown[];
  action_economics?: ActionEconomics[];
}

export interface NegativeKeywordItem {
  id: number;
  term_id: number;
  dataset_id: string;
  keyword: string;
  match_type: string;
  scope: string;
  campaign: string;
  ad_group: string;
  reason: string;
  estimated_waste: number;
  status: string;
}

export interface AuditLogItem {
  id: number;
  term_id: number;
  query: string;
  old_action: string;
  new_action: string;
  notes: string;
  timestamp: string;
}
